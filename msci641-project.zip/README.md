# msci641 project
 
This repository contains all the codebase used for the project submission for the MSCI-641.
The project contains the clickbait challenge and two tasks.
First task was to detect the correct type of spoiler a post should have. 
Prediction of these spoilerType were then used in the second task to generate the spoiler for the clickBait.

pip3 install -r requirements.txt

Files provided

analysis/   : Contains file to run Exploratory Data Analysis on the provided dataset.

data/input  : Contains the initial input train, val and test files.
data/output : Contains the output files generated from all the model configurations.

task1-classification : Contains the files used for the classification of spoilerType

task2-generative : Contains the files for generation of the spoilers using predictions from Task1.

utils : Contains file to support the editing of the data as per requirement